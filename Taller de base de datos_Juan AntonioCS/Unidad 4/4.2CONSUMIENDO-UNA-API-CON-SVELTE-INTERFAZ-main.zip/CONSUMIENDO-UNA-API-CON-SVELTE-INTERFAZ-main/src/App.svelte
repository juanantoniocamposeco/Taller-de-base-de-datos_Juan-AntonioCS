<script>
  import { onMount } from "svelte";

  let usuarios = [];
  let cargando = true;
  let error = "";
  let filtro = "";

  onMount(async () => {
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/users");
      if (!res.ok) {
        throw new Error("Error al obtener usuarios");
      }
      usuarios = await res.json();
    } catch (e) {
      error = e.message;
    } finally {
      cargando = false;
    }
  });

  $: usuariosFiltrados = usuarios.filter((u) =>
    u.name.toLowerCase().includes(filtro.toLowerCase())
  );
</script>
<main>
  <header>
    <h1>Consumiendo una API con Svelte</h1>
    <p>
      Esta página muestra una lista de usuarios obtenidos desde una API pública
      y los renderiza usando Svelte.
    </p>
  </header>

  <section class="panel-controles">
    <div>
      <label for="buscador">Buscar usuario:</label>
      <input
        id="buscador"
        type="text"
        placeholder="Escribe un nombre..."
        bind:value={filtro}
      />
    </div>
    <p class="contador">
      Total de usuarios: {usuariosFiltrados.length}
    </p>
  </section>

  {#if cargando}
    <p class="estado">Cargando usuarios...</p>
  {:else if error}
    <p class="estado error">Ocurrió un error: {error}</p>
  {:else if usuariosFiltrados.length === 0}
    <p class="estado">No se encontraron usuarios.</p>
  {:else}
    <section class="lista-usuarios">
      {#each usuariosFiltrados as usuario}
        <article class="tarjeta-usuario">
          <h2>{usuario.name}</h2>
          <p><strong>Usuario:</strong> {usuario.username}</p>
          <p><strong>Correo:</strong> {usuario.email}</p>
          <p><strong>Teléfono:</strong> {usuario.phone}</p>
          <p><strong>Ciudad:</strong> {usuario.address.city}</p>
          <p><strong>Empresa:</strong> {usuario.company.name}</p>
        </article>
      {/each}
    </section>
  {/if}

  <footer>
    <p>Práctica: Consumiendo una API con Svelte</p>
    <p>Alumno: eddi • Grupo: quinto sistemas</p>
  </footer>
</main>
<style>
  main {
    max-width: 1100px;
    margin: 0 auto;
    padding: 2rem 1.5rem;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background-color: #0f172a;
    color: #e5e7eb;
    min-height: 100vh;
  }

  header {
    margin-bottom: 2rem;
    text-align: center;
  }

  header h1 {
    font-size: 2rem;
    margin-bottom: 0.5rem;
    color: #38bdf8;
  }

  header p {
    font-size: 0.95rem;
    color: #cbd5f5;
  }

  .panel-controles {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
  }

  label {
    display: block;
    font-size: 0.85rem;
    margin-bottom: 0.25rem;
  }

  input[type="text"] {
    padding: 0.4rem 0.6rem;
    border-radius: 0.375rem;
    border: 1px solid #4b5563;
    background-color: #020617;
    color: #e5e7eb;
  }

  input[type="text"]::placeholder {
    color: #6b7280;
  }

  .contador {
    font-size: 0.9rem;
    color: #a5b4fc;
  }

  .estado {
    margin-top: 1rem;
    font-size: 0.95rem;
  }

  .estado.error {
    color: #fca5a5;
  }

  .lista-usuarios {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1rem;
  }

  .tarjeta-usuario {
    background-color: #020617;
    border-radius: 0.75rem;
    padding: 1rem;
    border: 1px solid #1f2937;
    box-shadow: 0 10px 25px rgba(15, 23, 42, 0.6);
  }

  .tarjeta-usuario h2 {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: #f97316;
  }

  .tarjeta-usuario p {
    font-size: 0.85rem;
    margin: 0.15rem 0;
  }

  .tarjeta-usuario strong {
    color: #e5e7eb;
  }

  footer {
    margin-top: 2rem;
    border-top: 1px solid #1f2937;
    padding-top: 1rem;
    font-size: 0.8rem;
    color: #9ca3af;
    text-align: center;
  }
</style>
