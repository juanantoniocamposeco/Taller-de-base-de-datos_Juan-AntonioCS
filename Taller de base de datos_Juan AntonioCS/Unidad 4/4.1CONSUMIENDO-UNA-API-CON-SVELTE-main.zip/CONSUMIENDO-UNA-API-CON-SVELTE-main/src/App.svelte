<script>
let listdata = [];

fetch("https://jsonplaceholder.typicode.com/users")
.then((Response)=>Response.json())
.then((results)=>listdata = results)



</script>

<uI>
{#each listdata as values}
<li>{values.id}{values.name}</li>
{/each}


</uI><i>




</i>