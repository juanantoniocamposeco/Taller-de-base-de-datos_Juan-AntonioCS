from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session

import models, schemas, services
from db import SessionLocal, engine

# Crear tablas en dbusers
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Conexión por petición
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def root():
    return {"message": "API conectada correctamente a dbusers sin contraseña"}

@app.get("/books")
def read_books(db: Session = Depends(get_db)):
    return services.get_books(db)

@app.post("/books")
def create_book(book: schemas.BookCreate, db: Session = Depends(get_db)):
    return services.create_book(db=db, book=book)
